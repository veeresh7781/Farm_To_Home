<?php
echo '<footer style="margin-top:10px;">';
echo '<p style="text-align:center; font-size:0.8em;">';
echo '&copy;';
echo 'Farm To Desk. All Rights Reserved.';
echo '</p>';
echo '</footer>';
echo '';
?>